package Ferrari_06_1;

public interface Car {

    String brakes();

    String gas();

}
