package CarShopExtend_02_1;

public interface Rentable {

    Integer getMinRentDay();

    Double getPricePerDay();

}
