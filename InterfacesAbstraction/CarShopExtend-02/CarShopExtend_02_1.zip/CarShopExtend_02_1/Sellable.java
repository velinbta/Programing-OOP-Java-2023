package CarShopExtend_02_1;

public interface Sellable {

    Double getPrice();

}
