package FoodShortage_04_1;

public interface Person extends Buyer {

    String getName();

    int getAge();

}
