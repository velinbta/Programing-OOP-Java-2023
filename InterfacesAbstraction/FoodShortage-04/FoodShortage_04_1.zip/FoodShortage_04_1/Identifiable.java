package FoodShortage_04_1;

public interface Identifiable {

    String getId();

}
