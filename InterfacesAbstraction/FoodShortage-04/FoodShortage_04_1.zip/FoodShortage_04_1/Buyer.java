package FoodShortage_04_1;

public interface Buyer {

    void buyFood();

    int getFood();

}
