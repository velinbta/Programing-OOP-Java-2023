package CarShop_01_1;

// Typo in horsePower given as two separated words
public class Seat implements Car {

    private final String model;
    private final String color;
    private final Integer horsePower;
    private final String countryProduced;

    public Seat(String model, String color, Integer horsePower, String countryProduced) {
        this.model = model;
        this.color = color;
        this.horsePower = horsePower;
        this.countryProduced = countryProduced;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override // Wrapper class requirement
    public Integer getHorsePower() {
        return this.horsePower;
    }

    @Override // No "get" requirement
    public String countryProduced() {
        return this.countryProduced;
    }

    @Override
    public String toString() {
        return String.format("This is %s produced in %s and have %d tires", this.getModel(),
                this.countryProduced(), Car.TIRES);
    }

}
