package BirthdayCelebrations_03_1;

public interface Birthable {

    String getBirthDate();

}
