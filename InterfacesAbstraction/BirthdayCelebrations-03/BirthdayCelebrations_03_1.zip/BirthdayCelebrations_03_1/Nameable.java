package BirthdayCelebrations_03_1;

public interface Nameable {

    String getName();

}
