package BirthdayCelebrations_03_1;

public interface Identifiable {

    String getId();

}
