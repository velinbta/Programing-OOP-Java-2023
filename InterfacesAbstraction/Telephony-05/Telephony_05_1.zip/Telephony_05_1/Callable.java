package Telephony_05_1;

public interface Callable {

    String call();

}
