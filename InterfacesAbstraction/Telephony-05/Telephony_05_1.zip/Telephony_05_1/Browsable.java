package Telephony_05_1;

public interface Browsable {

    String browse();

}
