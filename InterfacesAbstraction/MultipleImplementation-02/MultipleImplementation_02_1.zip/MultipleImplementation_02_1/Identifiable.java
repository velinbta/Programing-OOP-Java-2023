package MultipleImplementation_02_1;

public interface Identifiable {

    String getId();

}
