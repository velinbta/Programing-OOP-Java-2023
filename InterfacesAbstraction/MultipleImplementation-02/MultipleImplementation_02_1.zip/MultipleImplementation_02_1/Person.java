package MultipleImplementation_02_1;

public interface Person {

    String getName();

    int getAge();

}
