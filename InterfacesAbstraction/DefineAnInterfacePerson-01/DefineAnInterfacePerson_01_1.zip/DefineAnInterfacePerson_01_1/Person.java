package DefineAnInterfacePerson_01_1;

public interface Person {

    String getName();

    int getAge();

}
