package BorderControl_05_1;

public interface Identifiable {

    String getId();

}
