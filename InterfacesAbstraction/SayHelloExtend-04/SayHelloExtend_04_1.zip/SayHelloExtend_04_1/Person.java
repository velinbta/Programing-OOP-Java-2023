package SayHelloExtend_04_1;

public interface Person {

    String getName();

    String sayHello();

}
