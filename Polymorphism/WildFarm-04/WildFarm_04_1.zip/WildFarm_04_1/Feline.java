package WildFarm_04_1;

public abstract class Feline extends Mammal {

    protected Feline(String name, String type, Double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }

}
