package WildFarm_04_1;

public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }

}
