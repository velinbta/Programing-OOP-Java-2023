package WildFarm_04_1;

public class Vegetable extends Food {

    public Vegetable(Integer quantity) {
        super(quantity);
    }

}
