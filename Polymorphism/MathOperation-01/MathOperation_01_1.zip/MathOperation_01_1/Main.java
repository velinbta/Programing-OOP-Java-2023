package MathOperation_01_1;

public class Main {
    public static void main(String[] args) {

        // Sample code - class should contain only static methods, no instance needed, no state kept in this class
        MathOperation math = new MathOperation();

        System.out.println(math.add(2, 2));
        System.out.println(math.add(3, 3, 3));
        System.out.println(math.add(4, 4, 4, 4));

    }

}
