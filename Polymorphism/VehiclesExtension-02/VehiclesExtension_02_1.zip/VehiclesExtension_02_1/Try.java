package VehiclesExtension_02_1;

public class Try {
    public static void main(String[] args) {

        Car car = new Car(-0.1, 0.3, 16);

        System.out.println();






    }

}
