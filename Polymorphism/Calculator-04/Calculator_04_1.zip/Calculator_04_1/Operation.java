package Calculator_04_1;

public interface Operation {

    void addOperand(int operand);

    int getResult();

    boolean isCompleted();

}
