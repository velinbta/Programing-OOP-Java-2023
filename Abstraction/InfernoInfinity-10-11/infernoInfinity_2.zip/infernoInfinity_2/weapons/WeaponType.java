package infernoInfinity_2.weapons;

public enum WeaponType {

    AXE,
    KNIFE,
    SWORD;

}
