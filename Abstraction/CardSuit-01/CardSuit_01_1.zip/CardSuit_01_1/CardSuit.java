package CardSuit_01_1;

public enum CardSuit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}
