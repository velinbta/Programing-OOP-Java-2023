package bakery.entities.bakedFoods;

public interface BakedFood {

    String getName();

    double getPortion();

    double getPrice();

}
