package bakery.io;

public interface OutputWriter {

    void writeLine(String text);

}
