package easterRaces.io;

public interface OutputWriter {

    void writeLine(String text);

}
