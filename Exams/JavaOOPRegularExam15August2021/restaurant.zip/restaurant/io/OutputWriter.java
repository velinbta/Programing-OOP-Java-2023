package restaurant.io;

public interface OutputWriter {

    void writeLine(String text);

}
