package restaurant.entity.food;

public interface HealthyFood {

    String getName();

    double getPortion();

    double getPrice();

}
