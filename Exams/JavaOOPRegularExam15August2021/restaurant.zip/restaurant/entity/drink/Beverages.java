package restaurant.entity.drink;

public interface Beverages {

    String getName();

    int getCounter();

    double getPrice();

    String getBrand();

}
