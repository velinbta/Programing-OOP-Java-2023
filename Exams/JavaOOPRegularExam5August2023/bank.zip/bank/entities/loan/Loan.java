package bank.entities.loan;

public interface Loan {

    int getInterestRate();

    double getAmount();

}
