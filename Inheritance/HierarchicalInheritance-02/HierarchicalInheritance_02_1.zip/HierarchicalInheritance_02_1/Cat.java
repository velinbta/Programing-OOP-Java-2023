package HierarchicalInheritance_02_1;

public final class Cat extends Animal {

    public void meow() {
        System.out.println("meowing...");
    }

}
