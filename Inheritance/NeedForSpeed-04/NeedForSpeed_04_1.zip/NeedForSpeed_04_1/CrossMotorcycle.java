package NeedForSpeed_04_1;

public class CrossMotorcycle extends Motorcycle {

    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

}
