package NeedForSpeed_04_2;

public class CrossMotorcycle extends Motorcycle {

    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

}
