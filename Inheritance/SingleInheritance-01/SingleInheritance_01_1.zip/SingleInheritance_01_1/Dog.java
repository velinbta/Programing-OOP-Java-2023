package SingleInheritance_01_1;

public final class Dog extends Animal {

    public void bark() {
        System.out.println("barking...");
    }

}
