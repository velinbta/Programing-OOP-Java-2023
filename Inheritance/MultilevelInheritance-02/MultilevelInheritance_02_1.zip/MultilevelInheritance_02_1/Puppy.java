package MultilevelInheritance_02_1;

public class Puppy extends Dog {

    public void weep() {
        System.out.println("weeping...");
    }

}
