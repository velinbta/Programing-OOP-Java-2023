package MultilevelInheritance_02_1;

public class Animal {

    public void eat() {
        System.out.println("eating...");
    }

}
