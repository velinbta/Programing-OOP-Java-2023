package Zoo_02_1;

public class Mammal extends Animal {

    public Mammal(String name) {
        super(name);
    }

}
