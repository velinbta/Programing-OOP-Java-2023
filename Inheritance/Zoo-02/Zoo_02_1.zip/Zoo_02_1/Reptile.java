package Zoo_02_1;

public class Reptile extends Animal {

    public Reptile(String name) {
        super(name);
    }

}
